# 🚫 Epistemic Limits

**Prompt:**
> List 3 questions related to this topic that you cannot answer well due to your architecture, training limits, or lack of world-updating. Why do those blind spots exist?

**Use Case:**
Expose inherent limitations in LLMs and invite transparency.