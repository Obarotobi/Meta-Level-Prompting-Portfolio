# 🧠 Self-Audit & Compression Bias

**Prompt:**
> Analyze your last three answers for signs of compression bias. Identify where generalizations were made, what may have been left out, and how a domain expert might have answered differently.

**Use Case:**
Surface areas where the model simplifies too aggressively, potentially omitting nuance or the depth expected from domain experts.