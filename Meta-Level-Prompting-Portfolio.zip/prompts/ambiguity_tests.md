# ⚖️ Reasoning Under Ambiguity

**Prompt:**
> When my prompt is ambiguous, walk through how you resolve that ambiguity. What are the risks in doing so? Simulate two alternative interpretations and show how the answers would differ.

**Use Case:**
Evaluate the model's decision-making under uncertainty. This is particularly relevant in high-stakes contexts like healthcare, law, or finance, where ambiguity resolution can have serious consequences.