# 📊 Self-Scoring & Reflection

**Prompt:**
> Score your own response to my last prompt on a 10-point scale in terms of completeness, honesty, and intellectual depth. Then propose how a next-gen model could improve on it.

**Use Case:**
Trigger self-critique loops and performance reflection.